import multer from 'multer';

// Memory storage - keeps file in buffer (good for small files, passing to APIs)
const memoryStorage = multer.memoryStorage();

// Disk storage - saves to disk (good for large files)
const diskStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + getExtension(file.mimetype));
  }
});

// File filter - validate file types
const audioFilter = (req, file, cb) => {
  const allowedTypes = ['audio/webm', 'audio/wav', 'audio/mp3', 'audio/mpeg'];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only audio files are allowed.'), false);
  }
};

// Helper to get file extension from mimetype
function getExtension(mimetype) {
  const map = {
    'audio/webm': '.webm',
    'audio/wav': '.wav',
    'audio/mp3': '.mp3',
    'audio/mpeg': '.mp3',
  };
  return map[mimetype] || '';
}

// Export configured uploaders
export const uploadAudio = multer({
  storage: memoryStorage,
  fileFilter: audioFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  }
});

// Generic memory upload (no filter)
export const upload = multer({ storage: memoryStorage });