import { Router } from 'express';
import {createStreamingToken} from '../services/heygen.services.js';

const router = Router();

/**
* POST /api/heygen/token
* Get heygen streaming token
*/
router.post('/token', async (req, res) => {
  try {
    const data = await createStreamingToken();
    res.json(data);
  } catch (error) {
    console.error('HeyGen token error:', error);
    res.status(500).json({ error: error?.message || 'Failed to get HeyGen token' });
  }
});

export default router;