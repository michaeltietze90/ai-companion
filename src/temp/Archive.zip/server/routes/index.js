import { Router } from 'express';
import heygenRoutes from './heygen.routes.js';
import openaiRoutes from './openai.routes.js';
import salesforceRoutes from './salesforce.routes.js';

const router = Router();
router.use('/heygen', heygenRoutes);
router.use('/openai', openaiRoutes);
router.use('/salesforce', salesforceRoutes);

export default router;