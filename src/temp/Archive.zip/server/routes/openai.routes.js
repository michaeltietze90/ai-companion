import { Router } from 'express';
import { uploadAudio } from '../middleware/upload.js';
import { sendToWhisper } from '../services/openai.services.js';

const router = Router();

/**
* POST /api/openai/transcription
* Send audio to OpenAI Whisper API for transcription
*/
router.post('/transcription', uploadAudio.single('file'), async (req, res) => {
    try {
        const data = await sendToWhisper(req.file);
        res.json(data);
    } catch (error) {
        console.error('Transcription error:', error);
        res.status(500).json({ error: error?.message || 'Failed to transcribe audio' });
    }
});

export default router;
