import { Router } from 'express';
import { getSalesforceToken } from '../lib/salesforce-auth.js';
import {
    startSession,
    endSession,
    streamMessage,
} from '../services/salesforce.services.js';

const router = Router();

/**
* GET /api/salesforce/token
* Get Salesforce access token (mainly for debugging)
*/
router.get('/token', async (req, res) => {
    try {
        const token = await getSalesforceToken();
        // Don't expose full token in production - just confirm it works
        res.json({
            success: true,
            instance_url: token.instance_url,
            token_type: token.token_type,
        });
    } catch (error) {
        console.error('Token error:', error);
        res.status(500).json({ error: error?.message || 'Failed to get Salesforce token' });
    }
});

/**
* POST /api/salesforce/sessions
* Start a new Agentforce session
* Body: { agentId: string }
*/
router.post('/sessions', async (req, res) => {
    try {
      const { agentId } = req.body;
        const session = await startSession(agentId);
        res.json(session);
    } catch (error) {
        console.error('Start session error:', error);
        res.status(500).json({ error: error?.message || 'Failed to start session' });
    }
});

/**
 * DELETE /api/salesforce/sessions/:sessionId
 * End an Agentforce session
 */
router.delete('/sessions/:sessionId', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const result = await endSession(sessionId);
      res.json(result);
    } catch (error) {
      console.error('End session error:', error);
      res.status(500).json({ error: error?.message || 'Failed to end session' });
    }
  });
  
  /**
 * POST /api/salesforce/sessions/:sessionId/messages
 * Send a message and stream the response (SSE)
 * Body: { message: string }
 */
router.post('/sessions/:sessionId/messages', async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { message,sequenceId } = req.body;
  
      if (!message) {
        return res.status(400).json({ error: 'message is required' });
      }

      if (sequenceId === undefined) {
        return res.status(400).json({ error: 'sequenceId is required' });
      }
  
      const response = await streamMessage(sessionId, message, sequenceId);
  
      // Set up SSE headers for streaming
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
  
      // Pipe the Salesforce response stream to the client
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
  
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(decoder.decode(value));
      }
  
      res.end();
    } catch (error) {
      console.error('Stream message error:', error);
      res.status(500).json({ error: error.message });
    }
  });
  
  export default router;
