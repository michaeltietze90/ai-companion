export const createStreamingToken = async () => {
  const apiKey = process.env.HEYGEN_API_KEY;

  if (!apiKey) {
    throw new Error('HEYGEN_API_KEY not configured');
  }

  const response = await fetch('https://api.heygen.com/v1/streaming.create_token', {
    method: 'POST',
    headers: {
      'accept': 'application/json',
      'content-type': 'application/json',
      'x-api-key': apiKey,
    },
  });
  const data = await response.json();
  
  if (!response.ok) {
    throw new Error(data.message || 'Failed to get HeyGen token');
  }

  return data;  // Return data, don't use res.json()
}