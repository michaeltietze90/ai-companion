import { randomUUID } from 'crypto';

import { getSalesforceToken } from "../lib/salesforce-auth.js";

const AGENTFORCE_API_VERSION = 'v1';
const AGENTFORCE_API_DOMAIN = `https://api.salesforce.com`;
/**
 * Starts a new Agentforce session
 */
export async function startSession(agentId) {
  const { access_token, instance_url } = await getSalesforceToken();

  const externalSessionKey = randomUUID();

  const response = await fetch(
    `${AGENTFORCE_API_DOMAIN}/einstein/ai-agent/${AGENTFORCE_API_VERSION}/agents/${agentId}/sessions`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        externalSessionKey: externalSessionKey,
        instanceConfig: {
          endpoint: instance_url,
        },
        streamingCapabilities: {
          chunkTypes: ['Text'],
        },
        bypassUser: true,
      }),
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to start session: ${response.status} - ${errorText}`);
  }

  return response.json();
}

/**
 * Ends an Agentforce session
 */
export async function endSession(sessionId) {
  const { access_token } = await getSalesforceToken();

  const response = await fetch(
    `${AGENTFORCE_API_DOMAIN}/einstein/ai-agent/${AGENTFORCE_API_VERSION}/sessions/${sessionId}`,
    {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'x-session-end-reason': 'UserRequest'
      },
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to end session: ${response.status} - ${errorText}`);
  }

  return { success: true, sessionId };
}

/**
 * Sends a message and streams the response
 */
export async function streamMessage(sessionId, message, sequenceId) {
  const { access_token } = await getSalesforceToken();

  const response = await fetch(
    `${AGENTFORCE_API_DOMAIN}/einstein/ai-agent/${AGENTFORCE_API_VERSION}/sessions/${sessionId}/messages/stream`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream', 
      },
      body: JSON.stringify({
        message: {
          sequenceId: sequenceId,
          type: 'Text',
          text: message,
        },
      }),
    }
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Failed to send message: ${response.status} - ${errorText}`);
  }

  return response; // Return raw response for streaming
}