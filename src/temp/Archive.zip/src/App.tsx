import { useState, useCallback, useEffect } from 'react';
import { useHeygenAvatar } from './hooks/useHeygenAvatar';
import { AvatarStream } from './components/AvatarStream';
import { ControlBar } from './components/ControlBar';
import { Overlay } from './components/Overlay';
import { TabNavigation } from './components/TabNavigation';
import { BoxShadowTest } from './components/BoxShadowTest';
import { DEFAULT_AGENT_ID } from './lib/agents';

// Overlay asset paths
const IMAGE_OVERLAY_SRC = '/overlays/overlay-image.png';
const VIDEO_OVERLAY_SRC = '/output.webm';
// const VIDEO_OVERLAY_SRC = '/test.mov';
const AVATAR_ID = import.meta.env.VITE_AVATAR_ID;
function App() {
  // Tab state
  const [activeTab, setActiveTab] = useState<'main' | 'test'>('main');
  
  // Scale state for responsive 1080x1920 container
  const [scale, setScale] = useState(() => 
    typeof window !== 'undefined' 
      ? Math.min(window.innerHeight / 1920, window.innerWidth / 1080) 
      : 1
  );

  // agent state
  const [selectedAgentId, setSelectedAgentId] = useState(DEFAULT_AGENT_ID);

  useEffect(() => {
    const handleResize = () => {
      setScale(Math.min(window.innerHeight / 1920, window.innerWidth / 1080));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // HeyGen avatar hook
  const {
    status,
    error,
    videoRef,
    connect,
    disconnect,
    isMicMuted,
    toggleMic,
    isAvatarMuted,
    setAvatarMuted,
  } = useHeygenAvatar({
    avatarId: AVATAR_ID,
    // You can customize these:
    // avatarId: 'your-avatar-id',
    // voiceId: 'your-voice-id',
  });
  // Overlay visibility state
  const [isImageVisible, setIsImageVisible] = useState(false);
  const [isVideoVisible, setIsVideoVisible] = useState(false);

  // Handlers
  const handleConnect = useCallback(async () => {
    await connect(selectedAgentId);
  }, [connect]);

  const handleDisconnect = useCallback(async () => {
    await disconnect();
  }, [disconnect]);

  const handleToggleImage = useCallback(() => {
    setIsImageVisible((prev) => !prev);
  }, []);

  const handleToggleVideo = useCallback(() => {
    setIsVideoVisible((prev) => !prev);
  }, []);

  const handleSelectAgent = ((agentId: string) => {
    setSelectedAgentId(agentId);
  })

  const handleToggleAvatarMute = useCallback(() => {
    setAvatarMuted(!isAvatarMuted);
  }, [isAvatarMuted, setAvatarMuted]);

  const handleVideoEnded = useCallback(() => {
    setIsVideoVisible(false);
  }, []);

  // Get status text
  const getStatusText = () => {
    switch (status) {
      case 'connecting':
        return 'Connecting to avatar...';
      case 'connected':
        return 'Connected';
      case 'error':
        return error || 'Connection error';
      default:
        return 'Ready to connect';
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center">
      <div 
        className="w-[1080px] h-[1920px] overflow-hidden bg-surface rounded-3xl shadow-2xl border border-border"
        style={{ transform: `scale(${scale})` }}
      >
      {/* Tab Navigation - Always on top */}
      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Avatar View */}
      {activeTab === 'main' && (
        <>
          {/* Avatar stream (bottom layer) */}
          <AvatarStream videoRef={videoRef} status={status} />

          {/* Image overlay */}
          <Overlay
            type="image"
            src={IMAGE_OVERLAY_SRC}
            visible={isImageVisible}
          />

          {/* Video overlay */}
          <Overlay
            type="video"
            src={VIDEO_OVERLAY_SRC}
            visible={isVideoVisible}
            onVideoEnded={handleVideoEnded}
          />

          {/* Control bar (top layer) */}
          <ControlBar
            status={status}
            onConnect={handleConnect}
            onDisconnect={handleDisconnect}
            onShowImage={handleToggleImage}
            onShowVideo={handleToggleVideo}
            onSelectAgent={handleSelectAgent}
            isImageVisible={isImageVisible}
            isVideoVisible={isVideoVisible}
            isMicMuted={isMicMuted}
            isAvatarMuted={isAvatarMuted}
            onToggleMicMute={toggleMic}
            onToggleAvatarMute={handleToggleAvatarMute}
            selectedAgentId={selectedAgentId}
          />

          {/* Status indicator */}
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 py-3 px-6 bg-white/90 backdrop-blur-md rounded-full text-sm text-text-secondary shadow-lg border border-border">
            <span className={`w-2 h-2 rounded-full ${
              status === 'connecting' ? 'bg-warning animate-pulse-slow' :
              status === 'connected' ? 'bg-success' :
              status === 'error' ? 'bg-danger' : 'bg-text-muted'
            }`} />
            <span>{getStatusText()}</span>
          </div>
        </>
      )}

      {/* Hologram UI Test View */}
      {activeTab === 'test' && <BoxShadowTest />}
      </div>
    </div>
  );
}

export default App;
