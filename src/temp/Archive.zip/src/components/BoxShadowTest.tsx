export function BoxShadowTest() {
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-slate-50 to-slate-100 overflow-y-auto">
      <div className="px-10 pt-24 pb-10">
        <h1 className="text-3xl font-bold text-text-primary mb-12">Hologram UI</h1>
        
        <div className="grid grid-cols-2 gap-12">
          <div className="shadow-[-15px_50px_32px_rgba(0,0,0,0.25)] h-48 bg-white rounded-2xl p-6 border border-border/50 transition-transform duration-200 hover:-translate-y-1">
          Float Shadow
          </div>
          <div className="h-48 bg-white rounded-2xl p-6 border border-border/50 transition-transform duration-200 hover:-translate-y-1">
          Child Shadow
          <div className="mt-4 w-32 bg-blue-500 text-white rounded-md px-2 py-1 shadow-[0_1px_3px_rgba(0,0,0,0.20),0_6px_12px_rgba(0,0,0,0.20)] flex justify-center items-center">
            Learn more
          </div>
          </div>
          <div className="shadow-[-6px_0px_0px_rgba(0,0,0,0.25)] h-48 bg-white rounded-2xl p-6 border border-border/50 transition-transform duration-200 hover:-translate-y-1">
          Hard Shadow
          </div>
          <div className="h-48 bg-white rounded-2xl p-6 border border-border/50 transition-transform duration-200 hover:-translate-y-1">
            Inset Shadow
            <div className="shadow-[inset_0_4px_4px_rgba(0,0,0,0.25)] rounded-md px-2 py-1"> Typed Text</div>
          </div>
          <div className="h-48 bg-white rounded-2xl p-6 border border-border/50 transition-transform duration-200 hover:-translate-y-1">
            Border Stroke	
            <div className="w-24 h-24 bg-[#3b82f6] border-t-4 border-r-4 border-[rgb(119,165,242)] rounded-md rounded-tr-4xl"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
