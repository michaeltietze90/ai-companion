import type { ConnectionStatus } from '../hooks/useHeygenAvatar';
import { AGENTS } from '../lib/agents';
import { CustomSelect } from './CustomeSelect';

interface ControlBarProps {
  status: ConnectionStatus;
  onConnect: () => void;
  onDisconnect: () => void;
  onShowImage: () => void;
  onShowVideo: () => void;
  onSelectAgent: (agentId: string) => void;
  isImageVisible: boolean;
  isVideoVisible: boolean;
  isMicMuted: boolean;
  isAvatarMuted: boolean;
  onToggleMicMute: () => void;
  onToggleAvatarMute: () => void;
  selectedAgentId: string;
}

export function ControlBar({
  status,
  onConnect,
  onDisconnect,
  onShowImage,
  onShowVideo,
  onSelectAgent,
  isImageVisible,
  isVideoVisible,
  isMicMuted,
  isAvatarMuted,
  onToggleMicMute,
  onToggleAvatarMute,
  selectedAgentId,
}: ControlBarProps) {
  const isConnected = status === 'connected';
  const isConnecting = status === 'connecting';

  const baseButtonClass = "flex-1 flex flex-col items-center justify-center gap-2 py-5 px-4 rounded-2xl border font-medium text-sm transition-all duration-200 cursor-pointer";
  const defaultButtonClass = `${baseButtonClass} bg-surface border-border text-text-primary hover:bg-surface-tertiary hover:border-border-strong hover:-translate-y-0.5 active:translate-y-0`;
  const activeButtonClass = `${baseButtonClass} bg-accent border-transparent text-white`;

  return (
    <>
      {/* Main control buttons */}
      <div className="absolute top-20 left-0 right-0 z-60 px-10 py-6 flex gap-4 bg-gradient-to-b from-white/95 via-white/80 to-transparent backdrop-blur-sm">
        {/* Connect/Disconnect button */}
        <button
          className={`${baseButtonClass} ${
            isConnected 
              ? 'bg-danger/10 border-danger/30 text-danger hover:bg-danger/20' 
              : 'bg-accent border-transparent text-white font-semibold hover:bg-accent-dark hover:-translate-y-0.5'
          }`}
          onClick={isConnected ? onDisconnect : onConnect}
          disabled={isConnecting}
        >
          <span className="w-7 h-7 flex items-center justify-center">
            {isConnected ? (
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
              </svg>
            )}
          </span>
          <span>{isConnecting ? 'Connecting...' : isConnected ? 'Disconnect' : 'Connect'}</span>
        </button>

        {/* Show Image button */}
        <button
          className={isImageVisible ? activeButtonClass : defaultButtonClass}
          onClick={onShowImage}
        >
          <span className="w-7 h-7 flex items-center justify-center">
            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
            </svg>
          </span>
          <span>{isImageVisible ? 'Hide Image' : 'Show Image'}</span>
        </button>

        {/* Show Video button */}
        <button
          className={isVideoVisible ? activeButtonClass : defaultButtonClass}
          onClick={onShowVideo}
        >
          <span className="w-7 h-7 flex items-center justify-center">
            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 010 1.972l-11.54 6.347a1.125 1.125 0 01-1.667-.986V5.653z" />
            </svg>
          </span>
          <span>{isVideoVisible ? 'Hide Video' : 'Show Video'}</span>
        </button>
        <CustomSelect
          className={isVideoVisible ? activeButtonClass : defaultButtonClass}
          agents={AGENTS}
          selectedAgentId={selectedAgentId} // Or state if you track it
          onSelect={onSelectAgent}
          disabled={isConnected}
/>
      </div>

      {/* Mute controls row */}
      <div className="absolute top-52 left-10 right-10 z-50 flex gap-3">
        <button
          className={`flex-1 flex flex-col items-center justify-center gap-2.5 py-3.5 px-5 rounded-xl border font-medium text-sm transition-all duration-200 cursor-pointer ${
            isMicMuted 
              ? 'bg-danger/10 border-danger/30 text-danger' 
              : 'bg-white/80 backdrop-blur border-border text-text-secondary hover:text-text-primary hover:bg-white'
          }`}
          onClick={onToggleMicMute}
          disabled={!isConnected}
        >
          {isMicMuted ? (
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 19L5 5m7 14a7 7 0 01-7-7V9m14 3a7 7 0 01-.11 1.23M12 19v3m-4 0h8M12 14a3 3 0 01-3-3V5a3 3 0 016 0v6" />
            </svg>
          ) : (
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3zm0 0v3m0 3v-3m0 0a7 7 0 01-7-7m7 7a7 7 0 007-7m-11 0h-1m16 0h-1" />
            </svg>
          )}
          <span>{isMicMuted ? 'Mic Off' : 'Mic On'}</span>
          <div>
        <p id="recordingStatus"></p>
        </div>

        </button>

        <button
          className={`flex-1 flex items-center justify-center gap-2.5 py-3.5 px-5 rounded-xl border font-medium text-sm transition-all duration-200 cursor-pointer ${
            isAvatarMuted 
              ? 'bg-danger/10 border-danger/30 text-danger' 
              : 'bg-white/80 backdrop-blur border-border text-text-secondary hover:text-text-primary hover:bg-white'
          }`}
          onClick={onToggleAvatarMute}
          disabled={!isConnected}
        >
          {isAvatarMuted ? (
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707A1 1 0 0112 5v14a1 1 0 01-1.707.707L5.586 15zM17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
            </svg>
          ) : (
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M11 5L6 9H2v6h4l5 4V5zM15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14" />
            </svg>
          )}
          <span>{isAvatarMuted ? 'Avatar Muted' : 'Avatar Sound'}</span>
        </button>
      </div>
    </>
  );
}
