import { useState, useRef, useEffect } from 'react';

interface Agent {
  agentId: string;
  name: string;
}

interface CustomSelectProps {
  agents: Agent[];
  selectedAgentId: string;
  onSelect: (id: string) => void;
  disabled: boolean;
  className?: string;
}

export function CustomSelect({ agents, selectedAgentId, onSelect, disabled, className }: CustomSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown if clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = (id: string) => {
    onSelect(id);
    setIsOpen(false);
  };

  const selectedAgentName = agents.find(a => a.agentId === selectedAgentId)?.name || "Select Agent";

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>

      <button
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className={`w-full h-full flex flex-col items-center justify-center gap-2 outline-none ${disabled ? 'opacity-25 bg-gray-100' : ''}`}
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
        <span className="text-sm font-medium text-center leading-tight line-clamp-2 max-w-[120px]">{selectedAgentName}</span>
      </button>


      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-[60] min-w-[200px]">
          <ul className="py-1 max-h-60 overflow-y-auto">
            {agents.map((agent) => (
              <li key={agent.agentId}>
                <button
                  onClick={() => handleSelect(agent.agentId)}
                  className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                    agent.agentId === selectedAgentId
                      ? 'bg-blue-50 text-blue-600 font-semibold'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {agent.name}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}