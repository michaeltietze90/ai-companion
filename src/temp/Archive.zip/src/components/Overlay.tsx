import { useRef, useEffect } from 'react';

interface OverlayProps {
  type: 'image' | 'video';
  src: string;
  visible: boolean;
  onVideoEnded?: () => void;
}

export function Overlay({ type, src, visible, onVideoEnded }: OverlayProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (type === 'video' && videoRef.current) {
      if (visible) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch(console.error);
      } else {
        videoRef.current.pause();
      }
    }
  }, [visible, type]);

  // Video overlay should be above everything (z-[200]), image overlay below controls (z-40)
  const zIndex = type === 'video' ? 'z-[200]' : 'z-40';

  return (
    <div className={`absolute inset-0 ${zIndex} flex items-center justify-center pointer-events-none transition-opacity duration-300 ${visible ? 'opacity-100' : 'opacity-0'}`}>
      {type === 'image' ? (
        <img 
          src={src} 
          alt="Overlay" 
          className="max-w-full max-h-full object-contain"
        />
      ) : (
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className="overlay-video"
          onEnded={onVideoEnded}
        >
          <source src={src} type="video/webm" />
        </video>
      )}
    </div>
  );
}
