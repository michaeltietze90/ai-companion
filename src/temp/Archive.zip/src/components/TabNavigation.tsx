interface TabNavigationProps {
  activeTab: 'main' | 'test';
  onTabChange: (tab: 'main' | 'test') => void;
}

export function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  return (
    <div className="absolute top-6 left-1/2 -translate-x-1/2 z-[100] flex gap-0.5 p-1 bg-white/90 backdrop-blur-md rounded-full shadow-lg border border-border">
      <button
        className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 ${
          activeTab === 'main'
            ? 'bg-accent text-white shadow-md'
            : 'text-text-secondary hover:text-text-primary hover:bg-surface-tertiary'
        }`}
        onClick={() => onTabChange('main')}
        title="Avatar"
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
        </svg>
      </button>
      <button
        className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 ${
          activeTab === 'test'
            ? 'bg-accent text-white shadow-md'
            : 'text-text-secondary hover:text-text-primary hover:bg-surface-tertiary'
        }`}
        onClick={() => onTabChange('test')}
        title="Hologram UI"
      >
        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" />
        </svg>
      </button>
    </div>
  );
}
