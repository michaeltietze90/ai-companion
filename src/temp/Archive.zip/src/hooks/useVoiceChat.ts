import { useCallback, useRef, useState, useEffect } from "react";

/**
 * SENSITIVITY (0.0 to 1.0)
 * Determines how loud the sound must be to trigger "Speaking".
 * - Lower (e.g., 0.01): More sensitive. Picks up whispers but might trigger on background noise (AC, typing).
 * - Higher (e.g., 0.03): Less sensitive. Requires a clearer voice but ignores noise.
 * Current value 0.015 is a balanced starting point.
 */
const VAD_THRESHOLD = 0.015;  
/**
 * PAUSE TOLERANCE (milliseconds)
 * How long to wait after silence is detected before cutting the file.
 * - If you tend to pause while thinking, increase this (e.g., 2000ms).
 * - If the bot feels too slow to reply, decrease this (e.g., 1000ms).
 * 1500ms allows for natural pauses without cutting you off.
 */ 
const SILENCE_DURATION = 1500; 
/**
 * HALLUCINATION GUARD (milliseconds)
 * The recorder must run for at least this long to be valid.
 * This prevents sending tiny 100ms clips (like a mouse click or cough) 
 * to Whisper, which is the main cause of "Peace out" / "Thank you" hallucinations.
 */
const MIN_RECORDING_MS = 600; 
/**
 * POLLING RATE (milliseconds)
 * How often the code measures the microphone volume.
 * - 50ms = 20 times a second. High responsiveness, low CPU usage.
 * - Lowering this (e.g., 20ms) captures the very first millisecond of a word better 
 * but isn't usually necessary.
 */ 
const CHECK_INTERVAL = 50;

interface UseVoiceChatOptions {
  onStatusChange: (status: string) => void;
  onAgentResponse: (text: string) => void;
  getSessionId: () => string | null;
  getNextSequenceId: () => number;
  enabled?: boolean;
  isAvatarTalking?: boolean;
}

export function useVoiceChat({
  onStatusChange,
  onAgentResponse,
  getSessionId,
  getNextSequenceId,
  enabled = false,
  isAvatarTalking = false,
}: UseVoiceChatOptions) {
  const [isListening, setIsListening] = useState(false);
  const isProcessingRef = useRef(false);
  const enabledRef = useRef(enabled);
  const isAvatarTalkingRef = useRef(isAvatarTalking);

  // Audio Refs (Persistent)
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  
  // Logic Refs
  const isSpeakingRef = useRef(false);
  const silenceStartRef = useRef<number | null>(null);
  const intervalIdRef = useRef<number | null>(null);
  const recordingStartTimeRef = useRef<number>(0);

  // Sync refs
  useEffect(() => {
    enabledRef.current = enabled;
    // If disabled, we MUST kill the loop
    if (!enabled && isListening) stopListening();
  }, [enabled]);

  useEffect(() => {
    isAvatarTalkingRef.current = isAvatarTalking;
    if (isAvatarTalking && isSpeakingRef.current) {
        // If avatar interrupts, we discard current recording but KEEP LISTENING
        console.log("Avatar talking. Pausing capture (Mic still open).");
        isSpeakingRef.current = false;
        silenceStartRef.current = null;
        if (mediaRecorderRef.current?.state === 'recording') {
            mediaRecorderRef.current.stop();
            audioChunksRef.current = []; // Discard
        }
        onStatusChange("Listening..."); // Update UI to show we are still ready
    }
  }, [isAvatarTalking]);

  const sendToWhisper = useCallback(async (audioBlob: Blob) => {
    if (isProcessingRef.current || isAvatarTalkingRef.current) return;
    isProcessingRef.current = true;

    try {
      console.log(`Sending ${audioBlob.size} bytes...`);
      onStatusChange('Transcribing...');
      
      const formData = new FormData();
      formData.append('file', audioBlob, 'audio.webm'); 
      formData.append('model', 'whisper-1');
      formData.append('language', 'en');
      
      const response = await fetch('/api/openai/transcription', { method: 'POST', body: formData });
      const data = await response.json();
      const text = data.text ? data.text.trim() : "";
      
      if (!text) {
         onStatusChange('Listening...'); // Go back to ready state immediately
         return;
      }

      console.log('User said:', text);
      await sendToAgentforce(text);
    } catch (error) {
      console.error('Transcribe Error:', error);
      onStatusChange('Error: Retry?');
    } finally {
      isProcessingRef.current = false;
      // CRITICAL: Ensure we reflect "Listening" state when done
      if (enabledRef.current) onStatusChange('Listening...');
    }
  }, [onStatusChange, isAvatarTalking]); 

  const sendToAgentforce = useCallback(async (message: string) => {
    const sessionId = getSessionId();
    if (!sessionId) { onStatusChange('Error: No session'); return; }
    
    try {
      onStatusChange('Thinking...');
      const response = await fetch(`/api/salesforce/sessions/${sessionId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, sequenceId: getNextSequenceId() }),
      });

      if (!response.ok) throw new Error(`Status: ${response.status}`);
      
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let agentResponse = '';
      
      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const lines = decoder.decode(value).split('\n');
           for (const line of lines) {
             if (line.startsWith('data: ')) {
               try {
                 const event = JSON.parse(line.slice(6));
                 if (event.message?.type === 'Inform') agentResponse = event.message.message;
                 if (event.message?.type === 'ProgressIndicator') onStatusChange(event.message.message);
               } catch (e) {}
             }
           }
        }
      }
      if (agentResponse) onAgentResponse(agentResponse);

    } catch (error) {
      console.error('Agentforce Error:', error);
      onStatusChange('Error: Agentforce failed');
    }
  }, [getSessionId, getNextSequenceId, onStatusChange, onAgentResponse]);

  // --- CONTINUOUS LISTENING LOOP ---
  const startListening = useCallback(async () => {
    if (!enabledRef.current || isListening) return;

    try {
      console.log("Starting Continuous Listening...");
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          sampleRate: 48000, 
          channelCount: 1, 
          echoCancellation: true, 
          noiseSuppression: true, 
          autoGainControl: true 
        } 
      });
      streamRef.current = stream;

      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.1;
      
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);

      audioContextRef.current = audioContext;
      analyserRef.current = analyser;
      sourceNodeRef.current = source;

      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' });
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        // Logic runs when we cut a file, but the MIC stays open!
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        audioChunksRef.current = [];
        
        if (audioBlob.size > 2000 && !isAvatarTalkingRef.current) { 
           await sendToWhisper(audioBlob);
        } else {
           console.log("Ignored audio (too small/interrupted)");
           // If ignored, just go back to listening text
           onStatusChange("Listening...");
        }
      };

      isSpeakingRef.current = false;
      silenceStartRef.current = null;
      const dataArray = new Float32Array(analyser.frequencyBinCount);

      const checkVolume = () => {
        // If Avatar is talking, we act "deaf" but keep the stream alive
        if (isAvatarTalkingRef.current || !analyserRef.current) return;
        
        analyserRef.current.getFloatTimeDomainData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) sum += dataArray[i] * dataArray[i];
        const rms = Math.sqrt(sum / dataArray.length);

        if (rms > VAD_THRESHOLD) {
          // VOICE DETECTED
          silenceStartRef.current = null;
          
          if (!isSpeakingRef.current) {
            console.log(">> Voice Start (RMS:", rms.toFixed(3), ")");
            isSpeakingRef.current = true;
            onStatusChange("Listening..."); // Visual feedback
            
            // Start recording this segment
            if (mediaRecorderRef.current?.state === 'inactive') {
              audioChunksRef.current = [];
              mediaRecorderRef.current.start();
              recordingStartTimeRef.current = Date.now();
            }
          }
        } else {
          // SILENCE
          if (isSpeakingRef.current) {
            if (silenceStartRef.current === null) {
              silenceStartRef.current = Date.now();
            } else if (Date.now() - silenceStartRef.current > SILENCE_DURATION) {
              
              // Silence threshold met
              const duration = Date.now() - recordingStartTimeRef.current;
              
              if (duration < MIN_RECORDING_MS) {
                // Keep recording (too short)
              } else {
                console.log(">> Voice Stop. Sending...");
                isSpeakingRef.current = false;
                silenceStartRef.current = null;
                onStatusChange("Processing...");
                
                // Stop the recorder to trigger onstop -> whisper
                // NOTE: We do NOT call stopListening(), so the loop keeps running!
                if (mediaRecorderRef.current?.state === 'recording') {
                  mediaRecorderRef.current.stop();
                }
              }
            }
          }
        }
      };

      // Start the infinite loop
      intervalIdRef.current = window.setInterval(checkVolume, CHECK_INTERVAL);
      setIsListening(true);
      onStatusChange('Listening...'); // Ready immediately

    } catch (err) {
      console.error("VAD Setup Error:", err);
      onStatusChange('Error: Mic blocked');
    }
  }, [onStatusChange, sendToWhisper]); // Stable dependencies

  const stopListening = useCallback(() => {
    // This totally kills the mic (User clicks Mute)
    if (intervalIdRef.current) { clearInterval(intervalIdRef.current); intervalIdRef.current = null; }
    if (mediaRecorderRef.current?.state !== 'inactive') mediaRecorderRef.current?.stop();
    sourceNodeRef.current?.disconnect();
    audioContextRef.current?.close();
    streamRef.current?.getTracks().forEach(t => t.stop());
    setIsListening(false);
    onStatusChange('Muted');
  }, [onStatusChange]);

  const toggle = useCallback(() => {
    isListening ? stopListening() : startListening();
  }, [isListening, startListening, stopListening]);

  return {
    isMuted: !isListening,
    isLoading: false,
    isSpeaking: false,
    isErrored: false,
    toggle,
    mute: stopListening,
    unmute: startListening
  };
}