export const DEFAULT_AGENT_ID = '0XxHo000000MK8oKAG';

export const AGENTS = [
{ name: 'F1 Engagement Agent', agentId: '0XxHo000000MK8oKAG' }, 
{ name: 'Travel Agent', agentId: '0XxHo000000MLcEKAW' }, 
{ name: 'Function Calling Testing Agent', agentId: '0XxHo000000MOYmKAO' },
]