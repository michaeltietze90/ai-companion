import express from 'express';
import cors from 'cors';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';
import routes from './routes/index.js';
import { initializeWebsockets } from './services/websocket.services.js';
import http from 'http';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/api', routes);

// Serve static files from the Vite build in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(join(__dirname, '../dist')));
}

// Serve React app for all other routes in production
if (process.env.NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile(join(__dirname, '../dist/index.html'));
  });
}

// Create the HTTP server explicitly
const server = http.createServer(app);

// Attach WebSockets to the HTTP server
initializeWebsockets(server);

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

