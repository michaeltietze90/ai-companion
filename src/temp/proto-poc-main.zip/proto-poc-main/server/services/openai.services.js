export const sendToWhisper = async (file) => {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!file) {
    throw new Error('Audio file not provided');
  }

  if (!apiKey) {
    throw new Error('OPENAI_API_KEY not configured');
  }

  const formData = new FormData();
  formData.append('file', new Blob([file.buffer]), 'audio.webm');
  formData.append('model', 'whisper-1');

  const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
    },
    body: formData
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Transcription failed: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log('Received transcription:', data.text);
  return data;

}