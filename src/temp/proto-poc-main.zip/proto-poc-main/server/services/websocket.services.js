import { WebSocketServer, WebSocket } from 'ws';
import { URL } from 'url';
import { v4 as uuidv4 } from 'uuid';

// --- CONFIGURATION ---
const OPENAI_URL = 'wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-10-01';
const ALLOWED_ORIGINS = [
  'http://localhost:5173',
  'http://localhost:3001',
  'https://proto-poc-aabbccee479d.herokuapp.com' 
];

export function initializeWebsockets(httpServer) {
  const wss = new WebSocketServer({ noServer: true });

  httpServer.on('upgrade', (request, socket, head) => {
    const { pathname } = new URL(request.url, `http://${request.headers.host}`);
    
    // 1. Validate Path and Origin
    if (pathname !== '/transcribe') return;
    
    const origin = request.headers['origin'];
    if (origin && !ALLOWED_ORIGINS.includes(origin)) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return;
    }

    wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
    });
  });

  wss.on('connection', (clientWs, req) => {
    const traceId = req.headers['x-request-id'] || uuidv4();
    console.log(`[${traceId}] Client connected`);

    // --- CONNECT TO OPENAI REALTIME API ---
    const upstreamWs = new WebSocket(OPENAI_URL, {
        headers: {
            'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
            'OpenAI-Beta': 'realtime=v1',
        }
    });

    upstreamWs.on('open', () => {
        console.log(`[${traceId}] Connected to OpenAI`);
        
        // 1. Configure Session: Input Audio -> Text Output (Transcription only)
        const sessionConfig = {
            type: 'session.update',
            session: {
                modalities: ['text'], // We only want text back, not audio
                instructions: 'You are a transcriber. Transcribe exactly what the user says.',
                input_audio_transcription: {
                    model: 'whisper-1',
                },
                turn_detection: {
                    type: 'server_vad', // OpenAI detects when user stops talking
                    threshold: 0.5,
                    prefix_padding_ms: 300,
                    silence_duration_ms: 800 // Adjust silence detection speed
                }
            }
        };
        upstreamWs.send(JSON.stringify(sessionConfig));
    });

    upstreamWs.on('message', (data) => {
        try {
            const event = JSON.parse(data.toString());

            // 2. Listen for Transcription Events
            // This event fires when OpenAI finishes transcribing a user's sentence
            if (event.type === 'conversation.item.input_audio_transcription.completed') {
                const transcript = event.transcript;
                if (transcript) {
                    console.log(`[${traceId}] Transcript: ${transcript}`);
                    
                    // Send to Frontend in the format it expects
                    clientWs.send(JSON.stringify({
                        transcript: transcript,
                        isFinal: true
                    }));
                }
            }
            
            // Optional: Handle errors
            if (event.type === 'error') {
                console.error(`[${traceId}] OpenAI Error:`, event.error);
            }

        } catch (e) {
            console.error('Error parsing OpenAI message:', e);
        }
    });

    // --- HANDLE CLIENT AUDIO ---
    clientWs.on('message', (audioData) => {
        if (upstreamWs.readyState === WebSocket.OPEN) {
            // CRITICAL: Strip the 44-byte WAV header from RecordRTC chunks
            // RecordRTC sends a valid WAV file every 250ms. OpenAI wants RAW PCM.
            // If we don't strip bytes 0-44, the header sounds like static noise.
            const rawPcm = audioData.subarray(44); 

            // Send to OpenAI as Base64
            const audioEvent = {
                type: 'input_audio_buffer.append',
                audio: rawPcm.toString('base64')
            };
            upstreamWs.send(JSON.stringify(audioEvent));
        }
    });

    // Cleanup
    const closeAll = () => {
        if (clientWs.readyState === WebSocket.OPEN) clientWs.close();
        if (upstreamWs.readyState === WebSocket.OPEN) upstreamWs.close();
    };
    clientWs.on('close', closeAll);
    upstreamWs.on('close', closeAll);
    upstreamWs.on('error', (e) => console.error('Upstream error:', e));
  });
}