import type { RefObject } from 'react';
import type { ConnectionStatus } from '../hooks/useHeygenAvatar';

interface AvatarStreamProps {
  videoRef: RefObject<HTMLVideoElement | null>;
  status: ConnectionStatus;
}

export function AvatarStream({ videoRef, status }: AvatarStreamProps) {
  const showPlaceholder = status === 'disconnected' || status === 'error';
  const isConnecting = status === 'connecting';
  const showVideo = status === 'connected';

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-surface-secondary">
      {/* Video element for avatar stream */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        autoPlay
        playsInline
        style={{ display: showVideo ? 'block' : 'none' }}
      />

      {/* Placeholder when not connected */}
      {showPlaceholder && (
        <div className="flex flex-col items-center justify-center gap-6 text-center p-10">
          <div className="w-28 h-28 rounded-full bg-surface-tertiary border-2 border-dashed border-border-strong flex items-center justify-center">
            <svg className="w-12 h-12 text-text-muted" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
            </svg>
          </div>
          <h2 className="text-2xl font-semibold text-text-secondary">AI Avatar</h2>
          <p className="text-base text-text-muted max-w-[300px]">Click "Connect" to start interacting with the avatar</p>
        </div>
      )}

      {/* Loading state */}
      {isConnecting && (
        <div className="flex flex-col items-center justify-center gap-6 text-center p-10">
          <div className="w-12 h-12 border-3 border-border rounded-full border-t-accent animate-spin" />
          <h2 className="text-2xl font-semibold text-text-secondary">Connecting...</h2>
          <p className="text-base text-text-muted">Setting up your avatar session</p>
        </div>
      )}
    </div>
  );
}
