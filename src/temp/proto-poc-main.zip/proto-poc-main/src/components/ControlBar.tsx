import type { ConnectionStatus } from '../hooks/useHeygenAvatar';
import { AGENTS } from '../lib/agents';
import { AVATARS } from '../lib/avatars';
import SettingsDropdown from './SettingsDropdown';

interface ControlBarProps {
  status: ConnectionStatus;
  onConnect: () => void;
  onDisconnect: () => void;
  onShowImage?: () => void; // Optional, not displayed in floating bar
  onShowVideo: () => void;
  onSelectAgent: (agentId: string) => void;
  onSelectAvatar: (avatarId: string) => void;
  isImageVisible?: boolean; // Optional, not displayed in floating bar
  isVideoVisible: boolean;
  isMicMuted: boolean;
  isAvatarMuted: boolean;
  onToggleMicMute: () => void;
  onToggleAvatarMute: () => void;
  selectedAgentId: string;
  selectedAvatarId: string;
}

export function ControlBar({
  status,
  onConnect,
  onDisconnect,
  onShowVideo,
  onSelectAgent,
  onSelectAvatar,
  isVideoVisible,
  isMicMuted,
  isAvatarMuted,
  onToggleMicMute,
  onToggleAvatarMute,
  selectedAgentId,
  selectedAvatarId,
}: ControlBarProps) {
  const isConnected = status === 'connected';
  const isConnecting = status === 'connecting';

  // Base circular button styles - much bigger
  const circleBase = "w-24 h-24 flex items-center justify-center rounded-full transition-all duration-200 cursor-pointer shadow-[0_1px_3px_rgba(0,0,0,0.20),0_6px_12px_rgba(0,0,0,0.20)] backdrop-blur-sm";
  
  return (
    <div className="absolute right-8 top-1/2 -translate-y-1/2 z-50 flex flex-col gap-5">
      {/* Connect/Disconnect button */}
      <button
        className={`${circleBase} ${
          isConnected 
            ? 'bg-danger/90 text-white hover:bg-danger' 
            : 'bg-accent text-white hover:bg-accent-dark hover:scale-105'
        }`}
        onClick={isConnected ? onDisconnect : onConnect}
        disabled={isConnecting}
        title={isConnecting ? 'Connecting...' : isConnected ? 'Disconnect' : 'Start Session'}
      >
        {isConnecting ? (
          // Loading spinner
          <svg className="w-10 h-10 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
            <path d="M12 2a10 10 0 0 1 10 10" strokeLinecap="round" />
          </svg>
        ) : isConnected ? (
          // X icon for disconnect
          <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <path d="M6 18L18 6M6 6l12 12" />
          </svg>
        ) : (
          // Power/Play icon for connect - more relatable
          <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M5 3l14 9-14 9V3z" />
          </svg>
        )}
      </button>

      {/* Mic and Avatar controls - show right after connect when session is active */}
      {isConnected && (
        <>
          {/* Mic toggle button - 2nd position */}
          <button
            className={`${circleBase} ${
              isMicMuted 
                ? 'bg-danger/90 text-white' 
                : 'bg-white/90 text-text-secondary hover:bg-white hover:text-text-primary hover:scale-105'
            }`}
            onClick={onToggleMicMute}
            title={isMicMuted ? 'Unmute Mic' : 'Mute Mic'}
          >
            {isMicMuted ? (
              <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M19 19L5 5m7 14a7 7 0 01-7-7V9m14 3a7 7 0 01-.11 1.23M12 19v3m-4 0h8M12 14a3 3 0 01-3-3V5a3 3 0 016 0v6" />
              </svg>
            ) : (
              <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3zm0 0v3m0 3v-3m0 0a7 7 0 01-7-7m7 7a7 7 0 007-7m-11 0h-1m16 0h-1" />
              </svg>
            )}
          </button>

          {/* Avatar sound toggle button - 3rd position */}
          <button
            className={`${circleBase} ${
              isAvatarMuted 
                ? 'bg-danger/90 text-white' 
                : 'bg-white/90 text-text-secondary hover:bg-white hover:text-text-primary hover:scale-105'
            }`}
            onClick={onToggleAvatarMute}
            title={isAvatarMuted ? 'Unmute Avatar' : 'Mute Avatar'}
          >
            {isAvatarMuted ? (
              <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707A1 1 0 0112 5v14a1 1 0 01-1.707.707L5.586 15zM17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
              </svg>
            ) : (
              <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 5L6 9H2v6h4l5 4V5zM15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14" />
              </svg>
            )}
          </button>
        </>
      )}

      {/* Show Video button - Film/Movie icon */}
      <button
        className={`${circleBase} ${
          isVideoVisible 
            ? 'bg-accent text-white' 
            : 'bg-white/90 text-text-secondary hover:bg-white hover:text-text-primary hover:scale-105'
        }`}
        onClick={onShowVideo}
        title={isVideoVisible ? 'Hide Video' : 'Show Video'}
      >
        {/* Film/Video camera icon */}
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="2" y="6" width="13" height="12" rx="2" />
          <path d="M15 10l5-3v10l-5-3" />
        </svg>
      </button>

      {/* Agent/Settings selector button */}
      <SettingsDropdown
        disabled={isConnected}
        buttonClassName={`${circleBase} ${isConnected ? 'opacity-50 cursor-not-allowed' : ''
          } bg-white/90 text-text-secondary hover:bg-white hover:text-text-primary hover:scale-105`}
        sections={[
          {
            label: "Select Agent",
            items: AGENTS,
            selectedId: selectedAgentId,
            onSelect: (id: string) => onSelectAgent(id),
          },
          {
            label: "Select Avatar",
            items: AVATARS,
            selectedId: selectedAvatarId,
            onSelect: (id: string) => onSelectAvatar(id),
          },
        ]}
      />
    </div>
  );
}
