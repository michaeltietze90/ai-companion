import { useState, useEffect, useRef } from "react";

type Section = {
  label: string;
  items: { id: string; name: string }[];
  selectedId: string;
  onSelect: (id: string) => void;
};

type SettingsDropdownProps = {
  sections: Section[];
  disabled?: boolean;
  buttonClassName?: string;
};

const SettingsDropdown = ({ sections, disabled = false, buttonClassName }: SettingsDropdownProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;

    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen]);

  const handleSelect = (section: Section, id: string) => {
    section.onSelect(id);
    // Don't close - let user configure both if needed
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        className={buttonClassName}
        onClick={() => setIsOpen(!isOpen)}
        disabled={disabled}
        title="Settings"
      >
        {/* Gear icon */}
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute right-28 top-0 bg-white rounded-2xl shadow-xl border border-border overflow-hidden z-60 min-w-[280px]">
          {sections.map((section, index) => (
            <div key={section.label}>
              {/* Section header */}
              <div className={`px-4 py-3 bg-surface-secondary ${index > 0 ? 'border-t border-border' : ''}`}>
                <span className="text-xs font-semibold text-text-muted uppercase tracking-wide">
                  {section.label}
                </span>
              </div>
              {/* Section items */}
              <ul className="py-1 max-h-40 overflow-y-auto">
                {section.items.map((item) => (
                  <li key={item.id}>
                    <button
                      onClick={() => handleSelect(section, item.id)}
                      className={`w-full text-left px-4 py-2.5 text-sm transition-colors ${
                        item.id === section.selectedId
                          ? 'bg-accent/10 text-accent font-semibold'
                          : 'text-text-secondary hover:bg-surface-tertiary'
                      }`}
                    >
                      {item.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SettingsDropdown;