import { useCallback, useRef, useState } from 'react';
import StreamingAvatar, {
  AvatarQuality,
  StreamingEvents,
  VoiceEmotion,
  TaskType,
} from '@heygen/streaming-avatar';
import { DEFAULT_AVATAR_ID } from '../lib/avatars';
import { useVoiceChat } from './useVoiceChat';

export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

interface UseHeygenAvatarOptions {
  avatarId?: string;
  voiceId?: string;
}

interface UseHeygenAvatarReturn {
  status: ConnectionStatus;
  action: string | null;
  error: string | null;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  connect: (agentId: string) => Promise<void>;
  disconnect: () => Promise<void>;
  speak: (text: string) => Promise<void>;
  interrupt: () => Promise<void>;
  isMicMuted: boolean;
  toggleMic: () => void;
  isAvatarMuted: boolean;
  setAvatarMuted: (muted: boolean) => void;
  voiceStatus: string;
}

export function useHeygenAvatar(options: UseHeygenAvatarOptions = {}): UseHeygenAvatarReturn {
  const { avatarId = DEFAULT_AVATAR_ID, voiceId } = options;
  
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [action, setAction] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isAvatarMuted, setIsAvatarMuted] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState('');
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const avatarRef = useRef<StreamingAvatar | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const sfSessionRef = useRef<string | null>(null);
  const sequenceIdRef = useRef(1);

  // Memoize callbacks to prevent useVoiceChat from reinitializing
  const handleStatusChange = useCallback((s: string) => setVoiceStatus(s), []);
  const handleActionTrigger = useCallback((a: string) => setAction(a), []);
  
  const handleAgentResponse = useCallback(async (text: string) => {
    if (avatarRef.current) {
      console.log('Avatar speaking:', text);
      await avatarRef.current.speak({
        text,
        taskType: TaskType.REPEAT,
      });
    }
  }, []);

  const getSessionId = useCallback(() => sfSessionRef.current, []);
  const getNextSequenceId = useCallback(() => sequenceIdRef.current++, []);


 // Voice chat with VAD - auto-detects when you stop speaking
 // Voice chat with VAD - use memoized callbacks
  const voiceChat = useVoiceChat({
    onStatusChange: handleStatusChange,
    onActionTrigger: handleActionTrigger,
    onAgentResponse: handleAgentResponse,
    getSessionId,
    getNextSequenceId,
    // Only enable voice chat when fully connected
  enabled: status === 'connected',
  });

  const disconnect = useCallback(async () => {
    try {
      console.log('Disconnecting HeyGen avatar');
      if (avatarRef.current) {
        await avatarRef.current.stopAvatar();
        avatarRef.current = null;
      }
       // Mute voice chat first (closes the WebSocket connection)
       voiceChat.mute();
      // End Salesforce session
    if (sfSessionRef.current) {
      await fetch(`/api/salesforce/sessions/${sfSessionRef.current}`, {
        method: 'DELETE',
      });
      sfSessionRef.current = null;
    }
    // Reset sequence ID for next session
    sequenceIdRef.current = 1;

      
      
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
      mediaStreamRef.current = null;
      setStatus('disconnected');
    } catch (err) {
      console.error('Disconnect error:', err);
    }
  }, [voiceChat]);

  const connect = useCallback(async (agentId: string) => {
    try {
      setStatus('connecting');
      setError(null);

      const [tokenResponse, sfSessionResponse] = await Promise.all([
        // HeyGen token
        fetch('/api/heygen/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        }),
        // Salesforce Agentforce session
        fetch('/api/salesforce/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ agentId }),
        }),
      ]);

      if (!tokenResponse.ok) {
        throw new Error('Failed to get HeyGen access token');
      }
      if (!sfSessionResponse.ok) {
        throw new Error('Failed to start Salesforce session');
      }

      // Parse responses
    const [heygenData, sfSessionData] = await Promise.all([
      tokenResponse.json(),
      sfSessionResponse.json(),
    ]);

    const token = heygenData.data?.token;
    if (!token) {
      throw new Error('No HeyGen token received from server');
    }

    // Store Salesforce session ID for later use
    const sfSessionId = sfSessionData.sessionId;
    if (!sfSessionId) {
      throw new Error('No Salesforce session ID received');
    }

     sfSessionRef.current = sfSessionId;

    console.log('Salesforce session started:', sfSessionId);


      // Initialize StreamingAvatar
      const avatar = new StreamingAvatar({ token });
      avatarRef.current = avatar;

      // Set up event listeners
      avatar.on(StreamingEvents.STREAM_READY, (event) => {
        if (videoRef.current && event.detail) {
          videoRef.current.srcObject = event.detail;
          mediaStreamRef.current = event.detail;
          videoRef.current.play().catch(console.error);
        }
        setStatus('connected');
      });

      avatar.on(StreamingEvents.STREAM_DISCONNECTED, () => {
        disconnect();
      });

      avatar.on(StreamingEvents.AVATAR_START_TALKING, () => {
        console.log('Avatar started talking');
      });

      avatar.on(StreamingEvents.AVATAR_STOP_TALKING, () => {
        console.log('Avatar stopped talking');
      });

      /*
      * Starts a new avatar session using the provided configuration 
      * and returns session information.
      */
      await avatar.createStartAvatar({
        quality: AvatarQuality.High,
        avatarName: avatarId,
        voice: voiceId ? {
          voiceId,
          emotion: VoiceEmotion.FRIENDLY,
        } : undefined,
        disableIdleTimeout: true,
      });

    } catch (err) {
      console.error('Connection error:', err);
      setError(err instanceof Error ? err.message : 'Failed to connect');
      setStatus('error');
    }
  }, [avatarId, voiceId]);



  const speak = useCallback(async (text: string) => {
    if (avatarRef.current && status === 'connected') {
      await avatarRef.current.speak({
        text,
        taskType: TaskType.REPEAT,
      });
    }
  }, [status]);

  const interrupt = useCallback(async () => {
    if (avatarRef.current && status === 'connected') {
      await avatarRef.current.interrupt();
    }
  }, [status]);

  const setAvatarMuted = useCallback((muted: boolean) => {
    setIsAvatarMuted(muted);
    if (videoRef.current) {
      videoRef.current.muted = muted;
    }
  }, []);

  return {
    status,
    action,
    error,
    videoRef,
    connect,
    disconnect,
    speak,
    interrupt,
    isMicMuted: voiceChat.isMuted,
    toggleMic: voiceChat.toggle,
    voiceStatus,
    isAvatarMuted,
    setAvatarMuted,
  };
}

