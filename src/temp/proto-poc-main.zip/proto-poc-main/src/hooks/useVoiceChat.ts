import { useCallback, useRef, useState, useEffect } from "react";
import RecordRTC, { StereoAudioRecorder } from 'recordrtc';

interface UseVoiceChatOptions {
  onStatusChange: (status: string) => void;
  onActionTrigger: (action: string) => void;
  onAgentResponse: (text: string) => void;
  getSessionId: () => string | null;
  getNextSequenceId: () => number;
  enabled?: boolean;
  isAvatarTalking?: boolean;
}

interface TranscriptionEvent {
  transcript: string;
  isFinal: boolean;
}

const getWebSocketUrl = (endpoint: string) => {
  if (typeof window === 'undefined') {
    return ''; 
  }

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;
  
  return `${protocol}//${host}${endpoint}`;
};

export function useVoiceChat({
  onStatusChange,
  onActionTrigger,
  onAgentResponse,
  getSessionId,
  getNextSequenceId,
  enabled = false,
  isAvatarTalking = false,
}: UseVoiceChatOptions) {
  const [isListening, setIsListening] = useState(false);
  
  // Refs for State
  const socketRef = useRef<WebSocket | null>(null);
  const recorderRef = useRef<RecordRTC | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const isAvatarTalkingRef = useRef(isAvatarTalking);
  const accumulatedTextRef = useRef<string>("");
  const submitTimerRef = useRef<number | null>(null);

  // Sync refs
  useEffect(() => {
    isAvatarTalkingRef.current = isAvatarTalking;
    if (isAvatarTalking) {
      // If Avatar starts talking, cancel any pending user submission
      if (submitTimerRef.current) {
        clearTimeout(submitTimerRef.current);
        submitTimerRef.current = null;
      }
      accumulatedTextRef.current = ""; // Clear partial inputs
    }
  }, [isAvatarTalking]);

  const sendToAgentforce = useCallback(async (message: string) => {
    const sessionId = getSessionId();
    if (!sessionId || !message.trim()) return;

    try {
      onStatusChange('Thinking...');
      console.log("Sending to Agent:", message);
      
      const response = await fetch(`/api/salesforce/sessions/${sessionId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, sequenceId: getNextSequenceId() }),
      });

      if (!response.ok) throw new Error(`Status: ${response.status}`);
      
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullResponse = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const lines = decoder.decode(value).split('\n');
           for (const line of lines) {
             if (line.startsWith('data: ')) {
               try {
                 const event = JSON.parse(line.slice(6));
                 if (event.message?.type === 'Inform') fullResponse = event.message.message;
                 if (event.message?.type === 'ProgressIndicator') onActionTrigger(event.message.message);
               } catch (e) {}
             }
           }
        }
      }
      if (fullResponse) onAgentResponse(fullResponse);
      
      // Reset for next turn
      onStatusChange('Listening...'); 
      accumulatedTextRef.current = "";

    } catch (error) {
      console.error('Agentforce Error:', error);
      onStatusChange('Error: Agent failed');
    }
  }, [getSessionId, getNextSequenceId, onStatusChange, onAgentResponse]);


  const startListening = useCallback(async () => {
    if (isListening || !enabled) return;

    try {
      setIsListening(true);
      onStatusChange('Connecting...');
      
      // A. Get Microphone
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } 
      });
      streamRef.current = stream;

      // Setup Query Params for your Backend Proxy
      const queryParams = new URLSearchParams({
        'engine': 'aws', // or 'einstein'
        'language-code': 'en-US',
        'sample-rate': '16000',
        'number-of-channels': '1'
      }).toString();

      const wsUrl = getWebSocketUrl(`/transcribe?${queryParams}`);
      if (!wsUrl) {
        console.error("Cannot connect to WebSocket: Browser environment not detected.");
        onStatusChange("Error: Environment");
        return;
      }

      const socket = new WebSocket(wsUrl)
      socketRef.current = socket;

      socket.onopen = () => {
        console.log('WS Connected');
        onStatusChange('Listening...');

        // Start Recorder (16kHz WAV)
        const recorder = new RecordRTC(stream, {
            type: 'audio',
            mimeType: 'audio/wav',
            recorderType: StereoAudioRecorder,
            numberOfAudioChannels: 1,
            sampleRate: 44100,      
            desiredSampRate: 16000, 
            timeSlice: 250, // Send chunk every 250ms
            ondataavailable: (blob: Blob) => {
                // If socket is open and Avatar IS NOT talking
                if (socket.readyState === WebSocket.OPEN && !isAvatarTalkingRef.current) {
                    socket.send(blob);
                }
            }
        });
        recorderRef.current = recorder;
        recorder.startRecording();
      };

      // Handle Incoming Transcripts

      socket.onmessage = (event: MessageEvent) => {
        if (isAvatarTalkingRef.current) return; 

        try {
            const data: TranscriptionEvent = JSON.parse(event.data);
            
            // OpenAI Server VAD says the user is done talking
            if (data.transcript && data.isFinal) {
                 const text = data.transcript.trim();
                 
                 // Deduplicate: OpenAI sometimes sends the same final text twice
                 if (text && !accumulatedTextRef.current.endsWith(text)) {
                     accumulatedTextRef.current += " " + text;
                     console.log("OpenAI Turn Complete:", text);
                     
                     // ACTION: Send immediately! No timer needed.
                     // The backend 'silence_duration_ms' already handled the pause.
                     sendToAgentforce(accumulatedTextRef.current.trim());
                 }
            }
        } catch (e) {
            console.error("Parse Error", e);
        }
      };

      socket.onerror = (e) => {
          console.error("WebSocket Error", e);
          onStatusChange("Connection Error");
      };

      socket.onclose = () => {
          console.log("WebSocket Closed");
          stopListeningLogic();
      };

    } catch (err) {
      console.error("Mic Error:", err);
      onStatusChange('Error: Mic Blocked');
    }
  }, [enabled, isListening, onStatusChange, sendToAgentforce]);

  
  const stopListeningLogic = () => {
    setIsListening(false);
    
    // Clear Timer
    if (submitTimerRef.current) {
        clearTimeout(submitTimerRef.current);
        submitTimerRef.current = null;
    }

    // Stop Recorder
    if (recorderRef.current) {
        recorderRef.current.stopRecording(() => {
             recorderRef.current?.destroy();
             recorderRef.current = null;
        });
    }

    // Stop Stream
    if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
        streamRef.current = null;
    }
    
    // NOTE: We do NOT close the socket here recursively if it was triggered by socket.onclose
  };

  const stopListening = useCallback(() => {
     // User manually triggered stop
     if (socketRef.current) {
         socketRef.current.close();
         socketRef.current = null;
     }
     stopListeningLogic();
     onStatusChange('Muted');
  }, [onStatusChange]);

  const toggle = useCallback(() => {
    isListening ? stopListening() : startListening();
  }, [isListening, startListening, stopListening]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
        if (socketRef.current) socketRef.current.close();
        stopListeningLogic();
    };
  }, []);

  return {
    isMuted: !isListening,
    isLoading: false,
    isSpeaking: false,
    isErrored: false,
    toggle,
    mute: stopListening,
    unmute: startListening
  };
}