export const DEFAULT_AGENT_ID = '0XxHo000000MK8oKAG';

export const AGENTS = [
{ name: 'F1 Engagement Agent', id: '0XxHo000000MK8oKAG' }, 
{ name: 'Travel Agent', id: '0XxHo000000MLcEKAW' }, 
{ name: 'Function Calling Testing Agent', id: '0XxHo000000MOYmKAO' },
]