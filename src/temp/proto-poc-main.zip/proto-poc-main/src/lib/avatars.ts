export const DEFAULT_AVATAR_ID = "Thaddeus_ProfessionalLook2_public";

export const AVATARS = [
        {
        id: "Thaddeus_ProfessionalLook2_public",
        name: "Thaddeus Professional Look 2"
        },
        {
        id: "Thaddeus_ProfessionalLook_public",
        name: "Thaddeus Professional Look"
        },
        {
        id: "Pedro_ProfessionalLook2_public",
        name: "Pedro Professional Look 2"
        },
        {
        id: "Pedro_ProfessionalLook_public",
        name: "Pedro Professional Look"
        },
        {
        id: "Marianne_ProfessionalLook2_public",
        name: "Marianne Professional Look 2"
        },
        {
        id: "Marianne_ProfessionalLook_public",
        name: "Marianne Professional Look"
        },
        {
        id: "Katya_ProfessionalLook2_public",
        name: "Katya Professional Look 2"
        },
        {
        id: "Katya_ProfessionalLook_public",
        name: "Katya Professional Look"
        },
        {
        id: "Graham_ProfessionalLook2_public",
        name: "Graham Professional Look 2"
        },
        {
        id: "Graham_ProfessionalLook_public",
        name: "Graham Professional Look"
        },
        {
        id: "Anthony_ProfessionalLook2_public",
        name: "Anthony Professional Look 2"
        },
        {
        id: "Anthony_ProfessionalLook_public",
        name: "Anthony Professional Look"
        },
        {
        id: "Alessandra_ProfessionalLook2_public",
        name: "Alessandra Professional Look 2"
        },
        {
        id: "Alessandra_ProfessionalLook_public",
        name: "Alessandra Professional Look"
        },
        {
        id: "Anastasia_ProfessionalLook2_public",
        name: "Anastasia Professional Look 2"
        },
        {
        id: "Anastasia_ProfessionalLook_public",
        name: "Anastasia Professional Look"
        },
        {
        id: "Amina_ProfessionalLook2_public",
        name: "Amina Professional Look 2"
        },
        {
        id: "Amina_ProfessionalLook_public",
        name: "Amina Professional Look"
        },
        {
        id: "Rika_ProfessionalLook2_public",
        name: "Rika Professional Look 2"
        },
        {
        id: "Rika_ProfessionalLook_public",
        name: "Rika Professional Look"
        },
        {
        id: "Thaddeus_Black_Shirt_public",
        name: "Thaddeus in Black Shirt"
        },
        {
        id: "Thaddeus_Black_Suit_public",
        name: "Thaddeus in Black Suit"
        },
        {
        id: "Rika_Blue_Suit_public",
        name: "Rika in Blue Suit"
        },
        {
        id: "Rika_Black_Suit_public",
        name: "Rika in Black Suit"
        },
        {
        id: "Pedro_Black_Suit_public",
        name: "Pedro in Black Suit"
        },
        {
        id: "Pedro_Blue_Shirt_public",
        name: "Pedro in Blue Shirt"
        },
        {
        id: "Marianne_Black_Suit_public",
        name: "Marianne in Black Suit"
        },
        {
        id: "Marianne_Red_Suit_public",
        name: "Marianne in Red Suit"
        },
        {
        id: "Katya_Black_Suit_public",
        name: "Katya in Black Suit"
        },
        {
        id: "Katya_Pink_Suit_public",
        name: "Katya in Pink Suit"
        },
        {
        id: "Graham_Black_Suit_public",
        name: "Graham in Black Suit"
        },
        {
        id: "Graham_Black_Shirt_public",
        name: "Graham in Black Shirt"
        },
        {
        id: "Anthony_Black_Suit_public",
        name: "Anthony in Black Suit"
        },
        {
        id: "Anthony_White_Suit_public",
        name: "Anthony in White Suit"
        },
        {
        id: "Alessandra_Grey_Sweater_public",
        name: "Alessandra in Grey Sweater"
        },
        {
        id: "Alessandra_Black_Suit_public",
        name: "Alessandra in Black Suit"
        },
        {
        id: "Anastasia_Black_Suit_public",
        name: "Anastasia in Black Suit"
        },
        {
        id: "Anastasia_Grey_Shirt_public",
        name: "Anastasia in Grey Shirt"
        },
        {
        id: "Amina_Black_Suit_public",
        name: "Amina in Black Suit"
        },
        {
        id: "Amina_Blue_Suit_public",
        name: "Amina in Blue Suit"
        },
    ];
  
  export const STT_LANGUAGE_LIST = [
    { label: "Bulgarian", value: "bg", key: "bg" },
    { label: "Chinese", value: "zh", key: "zh" },
    { label: "Czech", value: "cs", key: "cs" },
    { label: "Danish", value: "da", key: "da" },
    { label: "Dutch", value: "nl", key: "nl" },
    { label: "English", value: "en", key: "en" },
    { label: "Finnish", value: "fi", key: "fi" },
    { label: "French", value: "fr", key: "fr" },
    { label: "German", value: "de", key: "de" },
    { label: "Greek", value: "el", key: "el" },
    { label: "Hindi", value: "hi", key: "hi" },
    { label: "Hungarian", value: "hu", key: "hu" },
    { label: "Indonesian", value: "id", key: "id" },
    { label: "Italian", value: "it", key: "it" },
    { label: "Japanese", value: "ja", key: "ja" },
    { label: "Korean", value: "ko", key: "ko" },
    { label: "Malay", value: "ms", key: "ms" },
    { label: "Norwegian", value: "no", key: "no" },
    { label: "Polish", value: "pl", key: "pl" },
    { label: "Portuguese", value: "pt", key: "pt" },
    { label: "Romanian", value: "ro", key: "ro" },
    { label: "Russian", value: "ru", key: "ru" },
    { label: "Slovak", value: "sk", key: "sk" },
    { label: "Spanish", value: "es", key: "es" },
    { label: "Swedish", value: "sv", key: "sv" },
    { label: "Turkish", value: "tr", key: "tr" },
    { label: "Ukrainian", value: "uk", key: "uk" },
    { label: "Vietnamese", value: "vi", key: "vi" },
  ];
